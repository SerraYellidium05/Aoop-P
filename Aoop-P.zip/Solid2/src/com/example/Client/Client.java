package com.example.Client;
import com.example.shapes.Circle;
import com.example.shapes.Rectangle;
import com.example.shapes.Shape;

public class Client {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle(10, 37);
        Shape circle = new Circle(46));

        // Calculate and print the area of the shapes
        System.out.println("Rectangle Area: " + rectangle.calculateArea());
        System.out.println("Circle Area: " + circle.calculateArea());
    }
}