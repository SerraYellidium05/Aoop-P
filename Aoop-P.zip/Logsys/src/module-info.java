/**
 * 
 */
/**
 * 
 */
module Logsys {
}