package com.example.logging;

public enum Loglevel {
	INFO,DEBUG,ERROR;
}


