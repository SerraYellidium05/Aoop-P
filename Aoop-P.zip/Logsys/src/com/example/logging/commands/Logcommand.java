package com.example.logging.commands;
import com.example.logging.command;
import com.example.logging.handlers.Loghangler;

public class Logcommand implements Command {
	private LogHandler handler;
	private string message;
	
	public Logcommand(Loghandler handler,string message) {
		this.handler=handler;
		this.message=message;
	}
	public void execute(string message) {
		handler.handleRequest(message);
	}
}
