package com.example.logging.client;
import com.example.logging.commands.LogCommand;
import com.example.logging.handlers.DebugHandler;
import com.example.logging.handlers.ErrorHandler;
import com.example.logging.handlers.InfoHandler;
import com.example.logging.iterator.Logger;
public class Client {
	
	InfoHandler infohandler =new InfoHandler();
	DebugHandler debugHandler =new DebugHandler();
	ErrorHandler errorHandler=new ErrorHandler();
	
	infoHandler.setNextHandler(debugHandler);
	debugHandler.setNextHandler(errorHandler);
	
	Logger logger=new Logger();
	logger,addCommand(new LogCommand(infoHandler,"Info message"));
	logger,addCommand(new LogCommand(infoHandler,"Debug message"));
	logger,addCommand(new LogCommand(infoHandler,"Error message"));
	
	logger.processCommands();
}

