package com.example.logging.handlers;

public class DebugHandler extends LogHandler{
	public void handleRequest(String message) {
        if (message.contains("DEBUG")) {
            System.out.println("DEBUG: " + message);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(message);
        }
    }
}
}
