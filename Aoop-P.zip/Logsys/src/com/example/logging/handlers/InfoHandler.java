package com.example.logging.handlers;

public class InfoHandler extends LogHandler {
	public void handlerequest(String message) {
		if(message.contains("INFO")) {
			System.out.println("INfo"+message);
		}
		else if(nextHandler!=null) {
			nextHandler.handleRequest(message);
		}
	}

}
