package com.example.logging.handlers;
import com.example.logging.Loglevel;

public abstract class Loghandler {
	protected Loghandler nexthandler;
}

public void setnextHandler(LogHandler nextHandler) {
	this.nexthandler=nextHandler;
}

public abstract void handleRequest(string message);
}