package com.example.logging.handlers;

public class handleRequest (string message){
	if (message.contains("ERROR")) {
        System.out.println("ERROR: " + message);
    } else if (nextHandler != null) {
        nextHandler.handleRequest(message);
    }
}
}
}
