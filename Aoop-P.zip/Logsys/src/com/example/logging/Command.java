package com.example.logging;

public interface Command {
	void execute(string message);
}


