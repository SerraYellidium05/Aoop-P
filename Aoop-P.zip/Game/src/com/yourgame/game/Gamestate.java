package com.yourgame.game;

public class Gamestate {
	private static Gamestate instance;
	private int level;
	private int difficulty;
	private Gamestate() {
		this.level=1;
		this.difficulty=1;
	}
	private static Gametart getInstance() {
		if(instance==null) {
			instance=Gamestate();
		}
		return  instance;
	}
	public int getlevel() {
		return level;
	}
	public void  setlevel(int level) {
		this.level=level;
	}
	public int getdifficulty() {
		return difficulty;
	}
	public void setdifficulty(int difficulty) {
		this.difficulty=difficulty;
	}
	public void setlevel() {
		level++;
	}
}
