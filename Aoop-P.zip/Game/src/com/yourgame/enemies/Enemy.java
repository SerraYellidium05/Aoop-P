package com.yourgame.enemies;

abstract class Enemy {
	abstract void attack();
}

class Eenemy extends Enemy{
	public void attack() {
		System.out.println("Easy enemy");
	}
}

class Menemy extends Enemy{
	public void attack() {
		System.out.println("Mid Enemy");
	}
}
class Henemy extends Enemy{
	public void attack() {
		System.out.println("hard Enemy");
	}
}


abstract class Enemyfactory{
	abstract Enemy createnemy();
}

class Eenemyfactory  extends Enemyfactory{
	Enemy createnemy() {
		return new Eenemy();
	}
}

class Menemyfactory  extends Enemyfactory{
	Enemy createnemy() {
		return new Menemy();
	}
}

class Henemyfactory  extends Enemyfactory{
	Henemy createnemy() {
		return new Henemy();
	}
}