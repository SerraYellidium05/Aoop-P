package com.yourgame.main;
import com.yourgame.game.*;
import com.yourgame.enemies.*;

public class Game {

	public static void main(String[] args) {
		Gamestate gamestate=Gamestate.getInstance();
		gamestate.setlevel(0);
		gamestate.setdifficulty(1);
		Enemyfactory enemyfactory;
		Enemyfactory gamefactory;
		
		switch(gamestate.getDifficulty()){
			case 1:
				enemyfactory=new Eenemyfactory();
				gamefactory=new Easygamefactory();
				break;
			case 2:
				enemyfactory=new Menemyfactory();
				gamefactory=new Midgamefactory();
				break;
			case 3:
				enemyfactory=new Henemyfactory();
				gamefactory=new Hardgamefactory();
				break;
		}
		Enemy enemy =Enemyfactory.createEnemy();
		enemy.attack();
		Weapon weapon=Gamefactory.createfactory();
		 PowerUp powerUp = elementFactory.createPowerUp();
	     powerUp.createpowerup();

	        gameState.nextLevel();
	    }
	}
		
	}

}
