package com.yourgame.weapons;

public interface Weapons {

}
