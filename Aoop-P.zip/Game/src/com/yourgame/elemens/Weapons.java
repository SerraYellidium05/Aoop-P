package com.yourgame.elemens;

public interface Weapons {
	void attack();
}

class Mweapon implements Weapons{
	public void attack() {
		System.out.println("Mid weapon");
	}
}

class Eweapon implements Weapons{
	public void attack() {
		System.out.println("Easy weapon");
	}
}

class Hweapon implements Weapons{
	public void attack() {
		System.out.println("Hard weapon");
	}
}


interface Poweup{
	void usepower();
}

class Easypower implements Powerup{
	public void usepower() {
		System.out.printn("Easy using power");
	}
}

class Midpower implements Powerup{
	public void usepower() {
		System.out.printn("Medium using power");
	}
}

class Hardpower implements Powerup{
	public void usepower() {
		System.out.printn("Hard using power");
	}
}


abstract class Gamefactory{
	Weapon createfactory();
	Powerup createpowerup();
}


class Easygamefactory extends Gamefactory{
	Weapon createfactory() {
		return new Eweapon();
	}
	Powerup createpowerup() {
		return new Easypower();
	}
}

class Midgamefactory  extends Gamefactory{
	Weapon createfactory() {
		return new Mweapon();
	}
	Powerup createpowerup() {
		return new Midpower();
	}
}


class Hardgamefactory  extends Gamefactory{
	Weapon createfactory() {
		return new Hweapon();
	}
	Powerup createpowerup() {
		return new Hardpower();
	}
}