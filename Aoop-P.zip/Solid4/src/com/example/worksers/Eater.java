package com.example.worksers;

public interface Eater {
	void eat();
}
