package com.example.worksers;

public interface Worker {
	void work();
}
