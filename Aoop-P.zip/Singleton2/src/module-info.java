/**
 * 
 */
/**
 * 
 */
module Singleton2 {
}