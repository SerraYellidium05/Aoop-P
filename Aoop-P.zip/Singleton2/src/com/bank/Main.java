package com.bank;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner value=new Scanner(System.in);
		Bank abc=new Bank();
		while(true) {
			string operation=value.nextLine();
			switch(operation) {
			case "view:"
			abc.viewBalance();
			break;
			case "deposit":
				System.out.println("enter amou nt to deposit");
				double deamount=value.nextDouble();
				abc.viewdpamount(deamount);
			break;
			case "withdraw":
				System.out..println("enter the withdraw");
				double wamount=value.nextDouble();
				abc.wpamount(wamount);
			break;
			case "exit":
				System.out.println("Exiting");
				return;
			default:
				system.out.println("Invalid");
			}
		}
	}
}
