package com.example.library;

import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;
    private BorrowingProcess borrowingProcess;

    public Library(BorrowingProcess borrowingProcess) {
        this.books = new ArrayList<>();
        this.borrowingProcess = borrowingProcess;
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void borrowBook(String title, Member member) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                borrowingProcess.borrowBook(book, member);
                return;
            }
        }
        System.out.println("Book not found: " + title);
    }
}