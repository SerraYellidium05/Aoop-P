package com.example.library;

public interface BorrowingProcess {
    void borrowBook(Book book, Member member);
}