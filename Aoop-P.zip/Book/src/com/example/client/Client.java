package com.example.client;

import com.example.library.Book;
import com.example.library.Library;
import com.example.library.Member;
import com.example.library.SimpleBorrowingProcess;

public class Client {
    public static void main(String[] args) {
        // Create a library and add books
        Library library = new Library(new SimpleBorrowingProcess());
        library.addBook(new Book("1984", "George Orwell"));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee"));

        // Create a member
        Member member = new Member("John Doe");

        // Borrow a book
        library.borrowBook("1984", member);
    }
}