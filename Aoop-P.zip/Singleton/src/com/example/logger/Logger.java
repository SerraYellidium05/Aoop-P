package com.example.logger;

public class Logger {
	public static Logger loggerInstance;
	private Logger() {
		
	}
	public static Logger getInstance() {
		if(loggerInstance==Null) {
			loggerInstance=new logger();
		}
		return loggerInstance;
	}
	 public void log(String message) {
	        System.out.println("Log: " + message);
	    }
}