package com.musicstream.main;

public class Main {

	public static void main(String[] args) {
		MusicSource localMusic =new MusicplayerAdapter(new LocalFilePlayer());
		MusicSource localMusic =new MusicplayerAdapter(new OnlineStreaminplayer());
		MusicSource localMusic =new MusicplayerAdapter(new Radioplayer());
	}
	localMusic.Musicon();
	onlineMusic.Musicon();
	radioMusic.Musicon();
	
	MusicPlayer player =new BasicMusicPlayer();
	player=new Equalizer(player);
	player=new VolumeControl(player);
	player.Musicon();
}
}
