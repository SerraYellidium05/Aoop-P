package com.musicstream.decorator;

public interface Musicplayer {
	void play();
}

public class Bmusicplayer implements Musicplayer{
	public void play() {
		System.out.println("Play music");
	}
}

public abstract class Musicplayerdecorator implements Musicplayer{
	protected Musicplayer decoratedPlayer;
	
	public MusicPlayerDecorator(MusicPlayer decoratedplayer) {
		this.decoratedPlayer=decoratedPlayer;
	}
	public void play() {
		decoratedPlayer.play();
	}
}

public class Equalizer extends MusicPlayerDecorator {
    public Equalizer(MusicPlayer decoratedPlayer) {
        super(decoratedPlayer);
    }

    public void play() {
        super.play();
        System.out.println("Applying equalizer settings.");
    }
}


public class Volumecontrol extends MusicPlayerDecorato{
	public VolumeControl(MusicPlayer decoratedPlayer) {
		super(decoratedPlayer);
	}
	public void play() {
		super.play();
		System.out.println("Volume adjuster");
	}
}