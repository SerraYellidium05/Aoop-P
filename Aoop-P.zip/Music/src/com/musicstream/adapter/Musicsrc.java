package com.musicstream.adapter;

public interface Musicsrc {
	void Musicon();
}

public class LocalFilePlayer{
	public void playLocalFile() {
		System.out.println("music from local files");
	}
}


public class OnlineStreaminplayer{
	public void streamMusic() {
		System.out.println("music from online");
	}
}


public class Radioplayer{
	public void radioplay() {
		System.out.println("Radio is playing");
	}
}

public class MusicPlayer implements Musicsrc{
	private Obj musicsrc;
	
	public Musicplayer(obj musicsrc) {
		this.musicsrc=musicsrc;
	}
	
	public void musicon() {
		if(musicsrc instanceof LocalFileplayer) {
			((LocalFileplayer) musicsrc).playLocalFile();)
		}
		else if (musicsrc instanceof OnlineStreaminplayer) {
			((OnlineStreaminplayer)musicsrc).streamMusic();
		}
		else if(musicsrc instanceof Radioplayer) {
			((Radioplayer)musicsrc).radioplay();
		}
	}
}
