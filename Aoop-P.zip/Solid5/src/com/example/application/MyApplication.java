package com.example.application;

import com.example.services.MessageService;

public class MyApplication {
    private final MessageService messageService;

    // Constructor Injection
    public MyApplication(MessageService messageService) {
        this.messageService = messageService;
    }

    public void processMessage(String message, String recipient) {
        messageService.sendMessage(message, recipient);
    }
}