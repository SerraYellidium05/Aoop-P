package com.example.employee;

public class Employee {
	private string name;
	private string role;
	
	public Employee(string name,string role6) {
		this.name=name;
		this.role=role;
	}
	
	public string getname() {
		return name;
	}
	
	public string getrole() {
		return role;
	}
	public string tostring() {
		return "Employee{Name ="+name+"","Role"+role+"'}';"
	}
}
