/**
 * 
 */
/**
 * 
 */
module Solid {
}