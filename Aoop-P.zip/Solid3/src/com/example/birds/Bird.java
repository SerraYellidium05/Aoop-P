package com.example.birds;

public class Bird {
	 public void fly() {
	        System.out.println("This bird is flying.");
	    }
}
