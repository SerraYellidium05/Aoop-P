package com.example.client;
import com.example.birds.Bird;
import com.example.birds.Ostrich;
public class Client {

	public static void main(String[] args) {
		Bird ostrich = new Ostrich();
        try {
            ostrich.fly();  // This will throw an exception
        } catch (UnsupportedOperationException e) {
            System.out.println(e.getMessage());
        }
    }
}
