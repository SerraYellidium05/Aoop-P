package com.vechicle.tansportway;

public abstract class Vechicles {
	public abstract void mode();
}

public class Car extends Vehicles{
	public void mode() {
		System.out.println("Car is selected");
	}
}

public class Bike extends Vehicles{
	public void mode() {
		System.out.println("Bike is selected");
	}
}


public class Scooter extends Vehicles{
	public void mode() {
		System.out.println("Scooter is selected");
	}
}

public class Bus extends Vehicles{
	public void mode() {
		System.out.println("Bus is selected");
	}
}

public abstract class Vechiclefactory{
	public abstract Vechicles createvechicle();
}

public class Carfactory extends Vechiclefactory{
	public Vechicle createvechicle() {
		return new Car();
	}
}


public class Bikefactory extends Vechiclefactory{
	public Vechicle createvechicle() {
		return new Bike();
	}
}



public class Scooterfactory extends Vechiclefactory{
	public Vechicle createvechicle() {
		return new Scooters();
	}
}





public class Busfactory extends Vechiclefactory{
	public Vechicle createvechicle() {
		return new Bus();
	}
}