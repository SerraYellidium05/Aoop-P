package com.vechicle.login;

public class Login {
	private static Login instance;
	private String Loginuser;
	
	private Login() {
		
	}
	
	public static Login getInstance() {
		if(instance==null) {
			instance=new Login();
		}
		return instance;
	}
	public void loginuser(String name,string pass) {
		this.Loginuser=name;
		System.out.println("user"+name+"logged in");
	}
	public String getloginuser() {
		return Loginuser;
	}
}
