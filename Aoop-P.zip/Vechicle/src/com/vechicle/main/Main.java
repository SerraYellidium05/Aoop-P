package com.vechicle.main;

public class Main {

	public static void main(String[] args) {
		Login login = login.getInstance();
		login.loginuser("Abcd", "answer");
		
		Vechiclefactory vehiclefactory = new Carfactory();
		Vechicle vechicle =vehicleFactory.createVechicle();
		vechicle.mode();
		
		
		Paymentmethodfactory paymentmethodfactory = new Cashpayment();
		Paymentmethod paymentmethod =paymentmethodfactory.createPaymentMethod();
		paymentmethod.pay(40.9);
		
		System.out.println("Ride for "+loginuser.getloginuser());
		

	}

}
