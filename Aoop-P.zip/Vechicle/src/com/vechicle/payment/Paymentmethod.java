package com.vechicle.payment;

public interface Paymentmethod {
	void pay(double amount);
}


class Cashpayment implements Paymentmethod{
	public void pay(double amount) {
		System.out.println("amount paid"+amount+"cashpayment");
	}
}


class payofpayment implements Paymentmethod{
	public void pay(double amount) {
		System.out.println("amount paid"+amount+"by pay of payment");
	}
}


class Netbankingpayment implements Paymentmethod{
	public void pay(double amount) {
		System.out.println("amount paid"+amount+"net banking");
	}
}


public abstract class Paymentmethodfactory{
	public abstract Paymentmethod createpayment();
}

public class Cashpaymentfactory extends Paymentmethodfactory{
	Paymentmethod createpayment() {
		return new Cashpayment();
	}
}


public class Payofpaymentfactory extends Paymentmethodfactory{
	Paymentmethod createpayment() {
		return new payofpayment();
	}
}


public class Netbankingpaymentfactory extends Paymentmethodfactory{
	Paymentmethod createpayment() {
		return new Netbankingpayment();
	}
}
